package controlLayer;

import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;

import javax.xml.bind.DataBindingException;

import DBLayer.DBCustomer;
import DBLayer.DBProduct;
import DBLayer.DBSaleOrder;
import DBLayer.GetMax;
import modelLayer.Customer;
import modelLayer.DeliveryStatus;
import modelLayer.Product;
import modelLayer.SaleOrder;
import modelLayer.SaleOrderLine;
import modelLayer.TypeOfPurchase;


public class SaleOrderController {
	
	private DBSaleOrder dbSaleOrder;
	private SaleOrder saleOrder;
	
	public SaleOrderController(){
		
		dbSaleOrder = new DBSaleOrder();
		
	}
	
	public void createSaleOrder(){
		saleOrder = new SaleOrder();
		int nextId = GetMax.getMaxId("Select max(saleOrderId) from SaleOrder");
		saleOrder.setId(nextId + 1);
	}
	
	public Customer addCustomerToSaleOrder(int customerId){
		CustomerController customerController = new CustomerController();
		Customer customer = customerController.getDbCustomer().getCustomerById(customerId, false);
		saleOrder.setCustomer(customer);
		return customer;
	}
	
	public void addProductToSaleOrder(int productId, int quantity) throws StockException{
		ProductController productController = new ProductController();
		Product product = productController.getProductById(productId, true);
		if(product.getStock() >= quantity || product.getStock() <= 0){
			SaleOrderLine saleOrderLine = new SaleOrderLine(saleOrder.getId(), quantity, TypeOfPurchase.SALE, product);
			saleOrder.addSaleOrderLine(saleOrderLine);
		}
		else{
			System.out.println("Stock Error: Current stock for: " + product.getName() + " is " + product.getStock());
			throw new StockException("Exceeds maximum stock \nCurrent Stock for " + product.getName()+": " + product.getStock());
		}
	}
	
	public int recordSaleOrder() throws Exception{
		int rc = dbSaleOrder.insertSaleOrder(saleOrder);
		return rc;
	}
	
	public SaleOrder getSaleOrderById(int saleOrderId, boolean retrieveAssociation){
		return dbSaleOrder.findSaleOrderById(saleOrderId, retrieveAssociation);
	}
	
	public void deleteSaleOrder(int saleOrderId){
		dbSaleOrder.deleteSaleOrder(getSaleOrderById(saleOrderId, true));
	}

	public DBSaleOrder getDbSaleOrder() {
		return dbSaleOrder;
	}

	public void setDbSaleOrder(DBSaleOrder dbSaleOrder) {
		this.dbSaleOrder = dbSaleOrder;
	}

	public SaleOrder getSaleOrder() {
		return saleOrder;
	}

	public void setSaleOrder(SaleOrder saleOrder) {
		this.saleOrder = saleOrder;
	}
	
	

	
}



