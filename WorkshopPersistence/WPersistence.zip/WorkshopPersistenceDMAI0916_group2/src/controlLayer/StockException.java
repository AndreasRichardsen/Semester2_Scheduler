package controlLayer;

public class StockException extends Exception {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public StockException(String message) {
        super(message);
    }
}