package controlLayer;

import java.sql.Date;
import java.time.LocalDate;

import DBLayer.DBProduct;
import DBLayer.DBWarehouse;
import DBLayer.GetMax;
import modelLayer.Product;
import modelLayer.SalePrice;
import modelLayer.Warehouse;

public class ProductController {
	
	private DBProduct dbProduct;
	
	public ProductController(){
		dbProduct = new DBProduct();
	}

	public DBProduct getDbProduct() {
		return dbProduct;
	}

	public void setDbProduct(DBProduct dbProduct) {
		this.dbProduct = dbProduct;
	}
	
	public Product createProduct(String name, String countryOfOrigin, String description, double salePrice, double rentPrice, int stock, int warehouseId, String productType){
		int nextId = GetMax.getMaxId("Select max(productId) from Product");
		nextId = nextId + 1;
		LocalDate localDate = LocalDate.now();
		Date date = Date.valueOf(localDate);
		DBWarehouse dbWarehouse = new DBWarehouse();
		Warehouse warehouse = dbWarehouse.getWarehouseById(warehouseId, false);
		Product product = new Product(nextId, name, countryOfOrigin, description, new SalePrice(nextId, salePrice, rentPrice, date), stock, warehouse, productType);
		return product;
	}
	
	public Product getProductById(int productId, boolean retrieveAssosicaiton){
		return dbProduct.getProductById(productId, retrieveAssosicaiton);
	}
	
	public void updateProduct(Product product){
		dbProduct.updateProduct(product);
	}
	
	public void deleteProduct(Product product){
		dbProduct.deleteProduct(product);
	}
	
	
	
	
	

}
