package controlLayer;

import DBLayer.DBCustomer;
import DBLayer.DBDiscount;
import DBLayer.GetMax;
import modelLayer.Customer;
import modelLayer.CustomerType;
import modelLayer.Discount;
import modelLayer.Customer;

public class CustomerController {
	
	private DBCustomer dbCustomer;
	private Customer customer;
	
	public CustomerController(){
		dbCustomer = new DBCustomer();
	}

	public DBCustomer getDbCustomer() {
		return dbCustomer;
	}

	public void setDbCustomer(DBCustomer dbCustomer) {
		this.dbCustomer = dbCustomer;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	
	public Customer createCustomer(String name, String address, String zipcode, String city, String phoneNo, String email, String customerType){
		int nextId = GetMax.getMaxId("Select max(customerId) from Customer");
		nextId = nextId + 1;
		CustomerType cType = dbCustomer.selectCustomerType(customerType);
		String discountType = dbCustomer.selectDiscountType(cType);
		DBDiscount DBdiscount = new DBDiscount();
		Discount discount = DBdiscount.getDiscountByType(discountType,false);
		Customer customer = new Customer(nextId, name, address, zipcode, city, phoneNo, email, cType, discount);
		return customer;
	}
	
	public Customer getCustomerById(int customerId, boolean retrieveAssosicaiton){
		return dbCustomer.getCustomerById(customerId, retrieveAssosicaiton);
	}
	
	public void updateCustomer(Customer customer){
		dbCustomer.updateCustomer(customer);
	}
	
	public void deleteCustomer(Customer customer){
		dbCustomer.deleteCustomer(customer);
	}

}
