package modelLayer;

public enum DiscountType {

	DEFAULT,
	CLUB_DISCOUNT;
}
