package modelLayer;

public class Product {

	private int id;
	private String name;
	private String countryOfOrigin;
	private String description;
	private SalePrice salePrice;
	private int stock;
	private Warehouse warehouse;
	private String productType;

	public Product() {
		super();
	}

	public Product(int id) {
		super();
		this.id = id;
	}

	public Product(int id, String name, String countryOfOrigin, String description, SalePrice salePrice, int stock,
			Warehouse warehouse, String productType) {
		super();
		this.id = id;
		this.name = name;
		this.countryOfOrigin = countryOfOrigin;
		this.description = description;
		this.salePrice = salePrice;
		this.stock = stock;
		this.warehouse = warehouse;
		this.productType = productType;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCountryOfOrigin() {
		return countryOfOrigin;
	}

	public void setCountryOfOrigin(String countryOfOrigin) {
		this.countryOfOrigin = countryOfOrigin;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public SalePrice getSalePrice() {
		return salePrice;
	}

	public void setSalePrice(SalePrice salePrice) {
		this.salePrice = salePrice;
	}

	public int getStock() {
		return stock;
	}

	public void setStock(int stock) {
		this.stock = stock;
	}

	public Warehouse getWarehouse() {
		return warehouse;
	}

	public void setWarehouse(Warehouse warehouse) {
		this.warehouse = warehouse;
	}

	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}

	@Override
	public String toString() {
		return "Product [id=" + id + ", name=" + name + ", countryOfOrigin=" + countryOfOrigin + ", description="
				+ description + ", salePrice=" + salePrice + ", stock=" + stock + ", warehouse=" + warehouse + "]";
	}





}
