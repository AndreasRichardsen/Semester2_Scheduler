package modelLayer;

public class SaleOrderLine {

	private int saleOrderId;
	private int quantity;
	private TypeOfPurchase typeOfPurchase;
	private Product product;


	public SaleOrderLine() {
		super();
	}

	public SaleOrderLine(int saleOrderId, int quantity, TypeOfPurchase typeOfPurchase, Product product) {
		super();
		this.saleOrderId = saleOrderId;
		this.quantity = quantity;
		this.typeOfPurchase = typeOfPurchase;
		this.product = product;
	}

	public int getSaleOrderId() {
		return saleOrderId;
	}

	public void setSaleOrderId(int saleOrderId) {
		this.saleOrderId = saleOrderId;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public TypeOfPurchase getTypeOfPurchase() {
		return typeOfPurchase;
	}

	public void setTypeOfPurchase(TypeOfPurchase typeOfPurchase) {
		this.typeOfPurchase = typeOfPurchase;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public static TypeOfPurchase selectTypeOfPurchase(String typeOfPurchase){
		if(typeOfPurchase.equalsIgnoreCase("SALE")){
			return TypeOfPurchase.SALE;
		}
		else if(typeOfPurchase.equalsIgnoreCase("RENT")){
			return TypeOfPurchase.RENT;
		}
		else{
			return null;
		}
	}

	public static String selectTypeOfPurchase(TypeOfPurchase typeOfPurchase){
		if(typeOfPurchase.equals(TypeOfPurchase.SALE)){
			return "SALE";
		}
		else if(typeOfPurchase.equals(TypeOfPurchase.RENT)){
			return "RENT";
		}
		else{
			return null;
		}
	}
	
}