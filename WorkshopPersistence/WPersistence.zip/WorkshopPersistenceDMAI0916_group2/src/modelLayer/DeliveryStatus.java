package modelLayer;

public enum DeliveryStatus {
	PROCESSING_ORDER,
	SHIPPING,
	DELIVERED;
}
