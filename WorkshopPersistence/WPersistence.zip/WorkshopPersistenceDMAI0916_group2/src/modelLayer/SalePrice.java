package modelLayer;

import java.util.Date;

public class SalePrice {
	
	private int productId;	
	private double salePrice;
	private double rentPrice;
	private Date startDate;

	public SalePrice() {
		super();
	}
	
	public SalePrice(int productId, double salePrice, double rentPrice, Date startDate) {
		super();
		this.productId = productId;
		this.salePrice = salePrice;
		this.rentPrice = rentPrice;
		this.startDate = startDate;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public double getSalePrice() {
		return salePrice;
	}

	public void setSalePrice(double salePrice) {
		this.salePrice = salePrice;
	}

	public double getRentPrice() {
		return rentPrice;
	}

	public void setRentPrice(double rentPrice) {
		this.rentPrice = rentPrice;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	@Override
	public String toString() {
		return "SalePrice [productId=" + productId + ", salePrice=" + salePrice + ", rentPrice=" + rentPrice
				+ ", startDate=" + startDate + "]";
	}
	

}
