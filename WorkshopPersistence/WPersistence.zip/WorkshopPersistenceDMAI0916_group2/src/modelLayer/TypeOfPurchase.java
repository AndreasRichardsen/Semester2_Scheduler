package modelLayer;

public enum TypeOfPurchase {

	SALE,
	RENT;
}
