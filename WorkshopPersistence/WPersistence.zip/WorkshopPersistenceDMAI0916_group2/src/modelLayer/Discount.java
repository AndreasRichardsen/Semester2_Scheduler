package modelLayer;

public class Discount {

	private DiscountType discountType;
	private double discountAmount;



	public Discount() {
		super();
	}

	public Discount(DiscountType discountType, double discountAmount) {
		super();
		this.discountType = discountType;
		this.discountAmount = discountAmount;
	}

	public DiscountType getDiscountType() {
		return discountType;
	}

	public void setDiscountType(DiscountType discountType) {
		this.discountType = discountType;
	}

	public double getDiscountAmount() {
		return discountAmount;
	}

	public void setDiscountAmount(double discountAmount) {
		this.discountAmount = discountAmount;
	}

	@Override
	public String toString() {
		return "Discount [discountType=" + discountType + ", discountAmount=" + discountAmount + "]";
	}

	public static DiscountType selectDiscountType(String discountType){
		if(discountType.equals("DEFAULT")){
			return DiscountType.DEFAULT;
		}
		else if(discountType.equals("CLUB_DISCOUNT")){
			return DiscountType.CLUB_DISCOUNT;
		}
		else{
			return null;
		}
	}


}
