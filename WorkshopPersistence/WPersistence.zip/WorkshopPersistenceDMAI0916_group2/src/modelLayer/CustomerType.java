package modelLayer;

public enum CustomerType {
	
	CLUB,
	PRIVATE_PERSON;
	
}
