package modelLayer;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Calendar;
import java.sql.Date;

public class SaleOrder {
	
	private int id;
	private Date date;
	private DeliveryStatus deliveryStatus;
	private Date deliveryDate;
	private Customer customer;
	private ArrayList<SaleOrderLine> saleOrderLines;
	private Invoice invoice;
	
	public SaleOrder() {
		super();
		this.deliveryStatus = DeliveryStatus.PROCESSING_ORDER;
		LocalDate localDate = LocalDate.now();
		this.date = Date.valueOf(localDate);
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.MONTH, 1);
		this.deliveryDate = new Date(cal.getTimeInMillis());
		createSaleOrderLineList();
	}

	public SaleOrder(int id, Date date, DeliveryStatus deliveryStatus, Date deliveryDate, Customer customer,
			ArrayList<SaleOrderLine> saleOrderLines, Invoice invoice) {
		super();
		this.id = id;
		this.date = date;
		this.deliveryStatus = deliveryStatus;
		this.deliveryDate = deliveryDate;
		this.customer = customer;
		this.saleOrderLines = saleOrderLines;
		this.invoice = invoice;
	}
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public DeliveryStatus getDeliveryStatus() {
		return deliveryStatus;
	}

	public void setDeliveryStatus(DeliveryStatus deliveryStatus) {
		this.deliveryStatus = deliveryStatus;
	}

	public Date getDeliveryDate() {
		return deliveryDate;
	}

	public void setDeliveryDate(Date deliveryDate) {
		this.deliveryDate = deliveryDate;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public ArrayList<SaleOrderLine> getSaleOrderLines() {
		return saleOrderLines;
	}

	public void setSaleOrderLines(ArrayList<SaleOrderLine> saleOrderLines) {
		this.saleOrderLines = saleOrderLines;
	}

	public Invoice getInvoice() {
		return invoice;
	}

	public void setInvoice(Invoice invoice) {
		this.invoice = invoice;
	}
	
	public void createSaleOrderLineList(){
		this.saleOrderLines = new ArrayList<SaleOrderLine>();
	}
	
	public void addSaleOrderLine(SaleOrderLine saleOrderLine){
		saleOrderLines.add(saleOrderLine);
	}

	@Override
	public String toString() {
		return "SaleOrder [id=" + id + ", date=" + date + ", deliveryStatus=" + deliveryStatus + ", deliveryDate="
				+ deliveryDate + ", customer=" + customer + ", saleOrderLines=" + saleOrderLines + ", invoice="
				+ invoice + "]";
	}
	
	public static CustomerType selectCustomerType(String customerType){
		if(customerType.equalsIgnoreCase("PRIVATE_PERSON")){
			return CustomerType.PRIVATE_PERSON;
		}
		else if(customerType.equalsIgnoreCase("CLUB")){
			return CustomerType.CLUB;
		}
		else{
			return null;
		}
	}

	public static String selectCustomerType(CustomerType customerType){
		if(customerType.equals(CustomerType.PRIVATE_PERSON)){
			return "PRIVATE_PERSON";
		}
		else if(customerType.equals(CustomerType.CLUB)){
			return "CLUB";
		}
		else{
			return null;
		}
	}

	public static String selectDiscountType(CustomerType customerType){
		if(customerType.equals(CustomerType.PRIVATE_PERSON)){
			return "DEFAULT";
		}
		else if(customerType.equals(CustomerType.CLUB)){
			return "CLUB_DISCOUNT";
		}
		else{
			return null;
		}
	}
	
	

	
	
	

}
