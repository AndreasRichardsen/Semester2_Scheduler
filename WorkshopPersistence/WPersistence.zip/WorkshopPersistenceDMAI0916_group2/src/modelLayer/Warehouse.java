package modelLayer;

public class Warehouse {
	
	private int id;
	private String name;
	private double capacity;
	private String warehouseType;
		
	public Warehouse() {
		super();
	}

	

	public Warehouse(int id, String name, double capacity, String warehouseType) {
		super();
		this.id = id;
		this.name = name;
		this.capacity = capacity;
		this.warehouseType = warehouseType;
	}



	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getCapacity() {
		return capacity;
	}

	public void setCapacity(double capacity) {
		this.capacity = capacity;
	}
	
	public String getWarehouseType() {
		return warehouseType;
	}

	public void setWarehouseType(String warehouseType) {
		this.warehouseType = warehouseType;
	}
	
	@Override
	public String toString() {
		return "Warehouse [id=" + id + ", name=" + name + ", capacity=" + capacity + ", warehouseType=" + warehouseType
				+ "]";
	}
	

}
