package modelLayer;

import java.util.Date;

public class Invoice {

	private int invoiceNo;
	private Date paymentDate;
	private SaleOrder saleOrder;
	
	public Invoice() {
		super();
	}

	public Invoice(int invoiceNo, Date paymentDate, SaleOrder saleOrder) {
		super();
		this.invoiceNo = invoiceNo;
		this.paymentDate = paymentDate;
		this.saleOrder = saleOrder;
	}

	public int getInvoiceNo() {
		return invoiceNo;
	}

	public void setInvoiceNo(int invoiceNo) {
		this.invoiceNo = invoiceNo;
	}

	public Date getPaymentDate() {
		return paymentDate;
	}

	public void setPaymentDate(Date paymentDate) {
		this.paymentDate = paymentDate;
	}

	public SaleOrder getSaleOrder() {
		return saleOrder;
	}

	public void setSaleOrder(SaleOrder saleOrder) {
		this.saleOrder = saleOrder;
	}

	@Override
	public String toString() {
		return "Invoice [invoiceNo=" + invoiceNo + ", paymentDate=" + paymentDate + ", saleOrder=" + saleOrder + "]";
	}
}
