package modelLayer;

public class Equipment extends Product {
	
	private String type;

	public Equipment() {
		super();
	}

	public Equipment(int id, String name, String countryOfOrigin, String description, SalePrice salePrice, int stock,
			Warehouse warehouse, String productType, String type) {
		super(id, name, countryOfOrigin, description, salePrice, stock, warehouse, productType);
		this.type = type;
	}
	
	@Override
	public int getId() {
		// TODO Auto-generated method stub
		return super.getId();
	}

	@Override
	public void setId(int id) {
		// TODO Auto-generated method stub
		super.setId(id);
	}

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return super.getName();
	}

	@Override
	public void setName(String name) {
		// TODO Auto-generated method stub
		super.setName(name);
	}

	@Override
	public String getCountryOfOrigin() {
		// TODO Auto-generated method stub
		return super.getCountryOfOrigin();
	}

	@Override
	public void setCountryOfOrigin(String countryOfOrigin) {
		// TODO Auto-generated method stub
		super.setCountryOfOrigin(countryOfOrigin);
	}

	@Override
	public String getDescription() {
		// TODO Auto-generated method stub
		return super.getDescription();
	}

	@Override
	public void setDescription(String description) {
		// TODO Auto-generated method stub
		super.setDescription(description);
	}

	@Override
	public SalePrice getSalePrice() {
		// TODO Auto-generated method stub
		return super.getSalePrice();
	}

	@Override
	public void setSalePrice(SalePrice salePrice) {
		// TODO Auto-generated method stub
		super.setSalePrice(salePrice);
	}

	@Override
	public int getStock() {
		// TODO Auto-generated method stub
		return super.getStock();
	}

	@Override
	public void setStock(int stock) {
		// TODO Auto-generated method stub
		super.setStock(stock);
	}

	@Override
	public Warehouse getWarehouse() {
		// TODO Auto-generated method stub
		return super.getWarehouse();
	}

	@Override
	public void setWarehouse(Warehouse warehouse) {
		// TODO Auto-generated method stub
		super.setWarehouse(warehouse);
	}

	@Override
	public String getProductType() {
		// TODO Auto-generated method stub
		return super.getProductType();
	}

	@Override
	public void setProductType(String productType) {
		// TODO Auto-generated method stub
		super.setProductType(productType);
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
	
	@Override
	public String toString() {
		return "Equipment [type=" + type + ", toString()=" + super.toString() + "]";
	}



}
