package JUnitTests;
import static org.junit.Assert.*;

import java.sql.Connection;
import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import DBLayer.DBConnection;
import DBLayer.DBCustomer;
import DBLayer.DBProduct;
import controlLayer.SaleOrderController;
import modelLayer.DeliveryStatus;
import modelLayer.SaleOrder;
import modelLayer.SaleOrderLine;
import modelLayer.TypeOfPurchase;

public class TestInsertSaleOrder{

	private SaleOrderController sOCon;
	private Connection con;

	@Before
	public void setUp() throws Exception{
		sOCon = new SaleOrderController();
		con = DBConnection.getInstance().getDBcon();
	}

	@After
	public void tearDown() throws Exception{
		sOCon.deleteSaleOrder(79);
		sOCon = null;
		con.close();
	}

	@Test
	public void testFindSaleOrderById() {
		//Arrange
		DBCustomer dbCustomer = new DBCustomer();
		DBProduct dbProduct = new DBProduct();
		LocalDate localDate = LocalDate.now();
		Date date = Date.valueOf(localDate);
		ArrayList<SaleOrderLine> list = new ArrayList<SaleOrderLine>();
		SaleOrderLine sol1 = new SaleOrderLine(79, 5, TypeOfPurchase.SALE, dbProduct.getProductById(1, true));
		SaleOrderLine sol2 = new SaleOrderLine(79, 2, TypeOfPurchase.SALE, dbProduct.getProductById(2, true));
		SaleOrderLine sol3 = new SaleOrderLine(79, 3, TypeOfPurchase.SALE, dbProduct.getProductById(3, true));
		list.add(sol1);
		list.add(sol2);
		list.add(sol3);

		SaleOrder saleOrder = new SaleOrder(79, date, DeliveryStatus.PROCESSING_ORDER, date, dbCustomer.getCustomerById(1, false), list, null);
		int rc = -1;

		//Act
		try {
			rc = sOCon.getDbSaleOrder().insertSaleOrder(saleOrder);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//Assert
		assertEquals(1, rc);



	}

}