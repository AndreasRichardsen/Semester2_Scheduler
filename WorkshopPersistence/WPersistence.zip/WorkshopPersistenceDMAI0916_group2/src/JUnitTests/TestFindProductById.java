package JUnitTests;
import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import controlLayer.ProductController;
import modelLayer.Product;

public class TestFindProductById{
	
	private ProductController prodCon;
	
	@Before
	public void setUp() throws Exception{
		prodCon = new ProductController();
	}
	
	@After
	public void tearDown() throws Exception{
		prodCon = null;
	}

	@Test
	public void testFindProductById() {
		//Arrange
		Product p1 = null;
		
		//Act
		p1 = prodCon.getProductById(1, false);
		
		//Assert
		assertNotNull(p1);
		
		
		
	}

}