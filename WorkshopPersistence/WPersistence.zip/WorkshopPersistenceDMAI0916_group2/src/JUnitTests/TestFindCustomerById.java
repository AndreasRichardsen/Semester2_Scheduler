package JUnitTests;
import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import controlLayer.CustomerController;
import modelLayer.Customer;

public class TestFindCustomerById{
	
	private CustomerController custCon;
	
	@Before
	public void setUp() throws Exception{
		custCon = new CustomerController();
	}
	
	@After
	public void tearDown() throws Exception{
		custCon = null;
	}

	@Test
	public void testFindCustomerById() {
		//Arrange
		Customer c1 = null;
		
		//Act
		c1 = custCon.getCustomerById(1, false);
		
		//Assert
		assertNotNull(c1);
		
		
		
	}

}
