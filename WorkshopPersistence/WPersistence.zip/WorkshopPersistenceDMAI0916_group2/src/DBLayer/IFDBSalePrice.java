package DBLayer;

import java.util.ArrayList;
import java.util.Date;

import modelLayer.SalePrice;

public interface IFDBSalePrice {
	
	public ArrayList<SalePrice> getAllSalePrices(boolean retrieveAssociation);
	public SalePrice getCurrentSalePriceByProductId(int productId, boolean retrieveAssociation);
	public SalePrice getSalePriceByProductIdAndDate(int productId, Date date, boolean retrieveAssociation);
	public int insertSalePrice(SalePrice SalePrice);
	public int updateSalePrice(SalePrice SalePrice);
	public int deleteSalePrice(SalePrice SalePrice);

}
