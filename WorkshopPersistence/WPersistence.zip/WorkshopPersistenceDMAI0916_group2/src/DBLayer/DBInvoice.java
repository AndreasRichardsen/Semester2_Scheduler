package DBLayer;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import modelLayer.Invoice;

public class DBInvoice implements IFDBInvoice {
	private Connection con;
	private int maxInvoiceNo;
	public DBInvoice()
	{
		con = DBConnection.getInstance().getDBcon();
	}

	@Override
	public ArrayList<Invoice> getAllInvoices(boolean retrieveAssociation) {
		return miscWhere("", retrieveAssociation);
	}

	@Override
	public Invoice getInvoiceByNo(int invoiceNo, boolean retrieveAssociation) {
		String wClause = "invoiceNo = " + invoiceNo;
		return singleWhere(wClause, retrieveAssociation);
	}
	
	public Invoice getInvoiceNoBySaleOrderId(int saleOrderId){
		String wClause = "saleOrderId = " + saleOrderId;
		return singleWhere(wClause, false);
	}

	@Override
	public int insertInvoice(Invoice invoice) {
		int nextNo = GetMax.getMaxId("Select max(invoiceNo) from Invoice");
		nextNo = nextNo + 1;
		System.out.println("next invoiceNo = " +  nextNo);
		maxInvoiceNo = nextNo;

		int rc = -1;

		String query="INSERT INTO Invoice(invoiceNo, SaleOrderId, paymentDate)  "
				+ "VALUES("+
				nextNo + "," +
				invoice.getSaleOrder().getId() + ",'"  +
				invoice.getPaymentDate() + "')";


		System.out.println("insert : " + query);
		try{ // insert new Customer +  dependent
			DBConnection.startTransaction();
			Statement stmt = con.createStatement();
			stmt.setQueryTimeout(5);
			rc = stmt.executeUpdate(query);
			stmt.close();
			DBConnection.commitTransaction();
		}//end try
		catch(SQLException ex){
			System.out.println("Invoice insertion error");
			DBConnection.rollbackTransaction();
			ex.printStackTrace();

		}
		return(rc);
	}
	
	public int getCurrentMaxInvoiceNo(){
		return maxInvoiceNo;
	}

	@Override
	public int updateInvoice(Invoice invoice) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int deleteInvoice(Invoice invoice) {
		// TODO Auto-generated method stub
		return 0;
	}
	
	private ArrayList<Invoice> miscWhere(String wClause, boolean retrieveAssociation)
	{
		ResultSet results;
		ArrayList<Invoice> list = new ArrayList<Invoice>();	

		String query =  buildQuery(wClause);

		try{ // read the Customer from the database
			Statement stmt = con.createStatement();
			stmt.setQueryTimeout(5);
			results = stmt.executeQuery(query);

			while( results.next() ){
				Invoice invObj = new Invoice();
				invObj = buildInvoice(results);	
				list.add(invObj);	
			}//end while
			stmt.close();     
			if(retrieveAssociation)
			{
				//do nothing	
			}
		}//end try	
		catch(Exception e){
			System.out.println("Query exception - select: "+e);
			e.printStackTrace();
		}
		return list;
	}
	
	private Invoice singleWhere(String wClause, boolean retrieveAssociation){
		ResultSet results;
		Invoice invObj = new Invoice();

		String query =  buildQuery(wClause);
		System.out.println(query);
		try{ // read the Discount from the database
			Statement stmt = con.createStatement();
			stmt.setQueryTimeout(5);
			results = stmt.executeQuery(query);

			if( results.next() ){
				invObj = buildInvoice(results);
				//association is to be build
				stmt.close();
				if(retrieveAssociation)
				{   
					//do nothing
				}
			}
			else{ 
				invObj = null;
			}
		}//end try	
		catch(Exception e){
			System.out.println("Query exception: "+e);
		}
		return invObj;
	}
	
	private String buildQuery(String wClause)
	{
		String query="SELECT invoiceNo, saleOrderId, paymentDate "
				+ "FROM Invoice";

		if (wClause.length()>0)
			query=query+" WHERE "+ wClause;

		return query;
	}
	
	private Invoice buildInvoice(ResultSet results)
	{  
		Invoice invObj = new Invoice();
		try{ // the columns from the table Discount  are used
			invObj.setInvoiceNo(results.getInt("invoiceNo"));
			invObj.setPaymentDate(results.getDate("paymentDate"));
			invObj.setSaleOrder(null);
			// change up
		}
		catch(Exception e)
		{
			System.out.println("error in building the Discount object");
		}
		return invObj;
	}
}
