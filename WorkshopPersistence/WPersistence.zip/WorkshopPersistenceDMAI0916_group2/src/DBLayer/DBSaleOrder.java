package DBLayer;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;

import modelLayer.SaleOrder;
import modelLayer.SaleOrderLine;
import modelLayer.TypeOfPurchase;
import modelLayer.Customer;
import modelLayer.DeliveryStatus;
import modelLayer.Invoice;

public class DBSaleOrder implements IFDBSaleOrder{

	private Connection con;

	public DBSaleOrder(){
		con = DBConnection.getInstance().getDBcon();
	}

	@Override
	public ArrayList<SaleOrder> getAllSaleOrders(boolean retrieveAssociation) {
		return miscWhere("", retrieveAssociation);
	}

	@Override
	public SaleOrder findSaleOrderById(int saleOrderId, boolean retrieveAssociation) {
		//				String wClause = "saleOrderId = " + saleOrderId;
		//				return singleWhere(wClause, retrieveAssociation);
		SaleOrder foundSaleOrder = null;

		ResultSet saleOrderResult;

		try{
			con = DBConnection.getInstance().getDBcon();
			DBConnection.startTransaction();
			PreparedStatement preparedstat = null;
			String baseQuery = "SELECT saleOrderId, so_date, deliveryStatus, deliveryDate, customerId, invoiceNo "
					+ "FROM SaleOrder "
					+ "Where saleOrderId = ?";
			preparedstat = con.prepareStatement(baseQuery);
			preparedstat.setInt(1, saleOrderId);
			saleOrderResult = preparedstat.executeQuery();
			if(saleOrderResult.next()){
				foundSaleOrder = buildSaleOrder(saleOrderResult);	

			}
			if(retrieveAssociation)
			{   
				//try catch later in case of null
				int customerId = saleOrderResult.getInt("customerId");
				DBCustomer dbCustomer = new DBCustomer();
				Customer customer = dbCustomer.getCustomerById(customerId,true);
				foundSaleOrder.setCustomer(customer);
				System.out.println("Customer is selected.");

				int invoiceNo = saleOrderResult.getInt("invoiceNo");
				DBInvoice dbInvoice = new DBInvoice();
				Invoice invoice = dbInvoice.getInvoiceByNo(invoiceNo, false);
				foundSaleOrder.setInvoice(invoice);
				System.out.println("Invoice is selected.");

				DBSaleOrderLine dbSaleOrderLine = new DBSaleOrderLine();
				ArrayList<SaleOrderLine> saleOrderLines = dbSaleOrderLine.getAllSaleOrderLines(foundSaleOrder.getId(), true);
					for(SaleOrderLine saleOrderLine : saleOrderLines){
						foundSaleOrder.addSaleOrderLine(saleOrderLine);
				}
				DBConnection.commitTransaction();

			}
		}
		catch(Exception e){
			System.out.println(e.getMessage());
			DBConnection.rollbackTransaction();
			e.printStackTrace();
		}

		return foundSaleOrder;
	}

	@Override
	public int insertSaleOrder(SaleOrder saleOrder) throws Exception {

		int rc = -1;

		try{
			con = DBConnection.getInstance().getDBcon();
			DBConnection.startTransaction();
			//Generate Invoice and insert Invoice
			DBInvoice dbInvoice = new DBInvoice();
			LocalDate localDate = LocalDate.now();
			Date date = Date.valueOf(localDate);
			Invoice invoice = new Invoice(0, date, saleOrder);
			dbInvoice.insertInvoice(invoice);
			saleOrder.setInvoice(invoice);
			saleOrder.getInvoice().setInvoiceNo((dbInvoice.getCurrentMaxInvoiceNo()));

			//insert Sale Order
			PreparedStatement preparedstat = null;
			String baseQuery = "INSERT INTO SaleOrder(saleOrderId, so_date, deliveryStatus, deliveryDate, customerId, invoiceNo)"
					+ "VALUES ( ?, ?, ?, ?, ?, ?)";

			preparedstat = con.prepareStatement(baseQuery);
			preparedstat.setInt(1, saleOrder.getId());
			preparedstat.setDate(2, (Date) saleOrder.getDate());
			preparedstat.setString(3, selectDeliveryStatus(saleOrder.getDeliveryStatus()));
			preparedstat.setDate(4, (Date) saleOrder.getDeliveryDate());
			preparedstat.setInt(5, saleOrder.getCustomer().getId());
			preparedstat.setInt(6, saleOrder.getInvoice().getInvoiceNo());
			rc = preparedstat.executeUpdate();

			//insert sale order lines
			DBSaleOrderLine dbSaleOrderLine = new DBSaleOrderLine();
			for(SaleOrderLine saleOrderLine : saleOrder.getSaleOrderLines()){
				saleOrderLine.setSaleOrderId(saleOrder.getId());
				saleOrderLine.setTypeOfPurchase(TypeOfPurchase.SALE);
				dbSaleOrderLine.insertSaleOrderLine(saleOrderLine);
			}
			DBConnection.commitTransaction();

		}
		catch(Exception e){
			System.out.println(e.getMessage());
			DBConnection.rollbackTransaction();
			e.printStackTrace();
			throw e;
		}

		return(rc);
	}

	@Override
	public int updateSaleOrder(SaleOrder SaleOrder) {
		int rc = -1;

		try{
			con = DBConnection.getInstance().getDBcon();
			DBConnection.startTransaction();

			//update Sale Order
			PreparedStatement preparedstat = null;
			String baseQuery = "UPDATE SaleOrder SET"
					+ "saleOrderId = ?, so_date = ?, deliveryStatus = ?, deliveryDate = ?, customerId = ?, invoiceNo = ?)"
					+ "Where saleOrderId = ?";

			preparedstat = con.prepareStatement(baseQuery);
			preparedstat.setInt(1, SaleOrder.getId());
			preparedstat.setDate(2, (Date) SaleOrder.getDate());
			preparedstat.setString(3, selectDeliveryStatus(SaleOrder.getDeliveryStatus()));
			preparedstat.setDate(4, (Date) SaleOrder.getDeliveryDate());
			preparedstat.setInt(5, SaleOrder.getCustomer().getId());
			preparedstat.setInt(6, SaleOrder.getInvoice().getInvoiceNo());
			preparedstat.setInt(7, SaleOrder.getId());
			rc = preparedstat.executeUpdate();

			//update sale order lines
			DBSaleOrderLine dbSaleOrderLine = new DBSaleOrderLine();
			for(SaleOrderLine saleOrderLine : SaleOrder.getSaleOrderLines()){
				dbSaleOrderLine.updateSaleOrderLine(saleOrderLine);
			}
			DBConnection.commitTransaction();;

		}
		catch(Exception e){
			System.out.println(e.getMessage());
			DBConnection.rollbackTransaction();
			e.printStackTrace();
		}
		return(rc);
	}

	@Override
	public int deleteSaleOrder(SaleOrder SaleOrder) {

		int rc=-1;

		try{ // delete from customer
			con = DBConnection.getInstance().getDBcon();
			DBConnection.startTransaction();
			PreparedStatement preparedstat = null;
			String baseQuery = "DELETE FROM SaleOrder WHERE saleOrderId = ?";
			preparedstat = con.prepareStatement(baseQuery);
			preparedstat.setInt(1, SaleOrder.getId());
			rc = preparedstat.executeUpdate();

			preparedstat = null;
			String baseQuery2 = "DELETE FROM Invoice WHERE invoiceNo = ?";
			preparedstat = con.prepareStatement(baseQuery2);
			preparedstat.setInt(1, SaleOrder.getInvoice().getInvoiceNo());
			rc = preparedstat.executeUpdate();

			DBConnection.commitTransaction();
		}//finish try	
		catch(Exception ex){
			System.out.println("Delete exception in SaleOrder db: "+ex);
			DBConnection.rollbackTransaction();
			ex.printStackTrace();
		}
		return(rc);


	}



	public ArrayList<SaleOrder> miscWhere(String wClause, boolean retrieveAssociation){
		ResultSet results;
		ArrayList<SaleOrder> list = new ArrayList<SaleOrder>();	

		String query =  buildQuery(wClause);

		try{ // read the SaleOrder from the database
			Statement stmt = con.createStatement();
			stmt.setQueryTimeout(5);
			results = stmt.executeQuery(query);


			while( results.next() ){
				SaleOrder saleOrderObj = new SaleOrder();
				saleOrderObj = buildSaleOrder(results);	
				list.add(saleOrderObj);	
			}//end while
			stmt.close();     
			if(retrieveAssociation)
			{   //The supervisor and department is to be build as well
				for(SaleOrder saleOrderObj : list){
					//try catch later in case of null
					int customerId = results.getInt("customerId");
					DBCustomer dbCustomer = new DBCustomer();
					Customer customer = dbCustomer.getCustomerById(customerId,true);
					saleOrderObj.setCustomer(customer);
					System.out.println("Customer is selected.");

					int invoiceNo = results.getInt("invoiceNo");
					DBInvoice dbInvoice = new DBInvoice();
					Invoice invoice = dbInvoice.getInvoiceByNo(invoiceNo, false);
					saleOrderObj.setInvoice(invoice);
					System.out.println("Invoice is selected.");

					DBSaleOrderLine dbSaleOrderLine = new DBSaleOrderLine();
					ArrayList<SaleOrderLine> saleOrderLines = dbSaleOrderLine.getAllSaleOrderLines(saleOrderObj.getId(), true);
					for(SaleOrderLine saleOrderLine : saleOrderLines){
						saleOrderObj.addSaleOrderLine(saleOrderLine);
					}
				}
			}//end if   

		}//finish try	
		catch(Exception e){
			System.out.println("Query exception - select: "+e);
			e.printStackTrace();
		}
		return list;
	}

	private SaleOrder singleWhere(String wClause, boolean retrieveAssociation){
		ResultSet results;
		SaleOrder saleOrderObj = new SaleOrder();

		String query =  buildQuery(wClause);
		System.out.println(query);

		PreparedStatement preparedstat = null;
		String baseQuery = buildQuery(wClause);

		try{ // read the SaleOrderfrom the database
			Statement stmt = con.createStatement();
			stmt.setQueryTimeout(5);
			results = stmt.executeQuery(query);

			if( results.next() ){
				saleOrderObj = buildSaleOrder(results);
				//Association is to be build
				stmt.close();
				if(retrieveAssociation)
				{   
					//try catch later in case of null
					int customerId = results.getInt("customerId");
					DBCustomer dbCustomer = new DBCustomer();
					Customer customer = dbCustomer.getCustomerById(customerId,true);
					saleOrderObj.setCustomer(customer);
					System.out.println("Customer is selected.");

					int invoiceNo = results.getInt("invoiceNo");
					DBInvoice dbInvoice = new DBInvoice();
					Invoice invoice = dbInvoice.getInvoiceByNo(invoiceNo, false);
					saleOrderObj.setInvoice(invoice);
					System.out.println("Invoice is selected.");

					DBSaleOrderLine dbSaleOrderLine = new DBSaleOrderLine();
					ArrayList<SaleOrderLine> saleOrderLines = dbSaleOrderLine.getAllSaleOrderLines(saleOrderObj.getId(), true);
					for(SaleOrderLine saleOrderLine : saleOrderLines){
						saleOrderObj.addSaleOrderLine(saleOrderLine);
					}
				}
			}
			else{ //no SaleOrder was found
				saleOrderObj = null;
			}
		}//end try	
		catch(Exception e){
			System.out.println("Query exception: "+e);
		}
		return saleOrderObj;

	}

	private String buildQuery(String wClause)
	{
		String query="SELECT saleOrderId, so_date, deliveryStatus, deliveryDate, customerId, invoiceNo "
				+ "FROM SaleOrder";

		if (wClause.length()>0)
			query=query+" WHERE "+ wClause;

		return query;
	}

	private SaleOrder buildSaleOrder(ResultSet results)
	{   SaleOrder saleOrderObj = new SaleOrder();
	try{ // the columns from the table SaleOrder  are used
		saleOrderObj.setId(results.getInt("SaleOrderId"));
		saleOrderObj.setDate(results.getDate("so_date"));
		saleOrderObj.setDeliveryStatus(selectDeliveryStatus(results.getString("deliveryStatus")));
		saleOrderObj.setDeliveryDate(results.getDate("deliveryDate"));
		saleOrderObj.setCustomer(null);
		saleOrderObj.createSaleOrderLineList();
		saleOrderObj.setInvoice(null);
	}
	catch(Exception e)
	{
		System.out.println("error in building the SaleOrder object");
	}
	return saleOrderObj;
	}

	private DeliveryStatus selectDeliveryStatus(String deliveryStatus){
		if(deliveryStatus.equalsIgnoreCase("PROCESSING_ORDER")){
			return DeliveryStatus.PROCESSING_ORDER;
		}
		else if(deliveryStatus.equalsIgnoreCase("SHIPPING")){
			return DeliveryStatus.SHIPPING;
		}
		else if(deliveryStatus.equalsIgnoreCase("DELIVERED")){
			return DeliveryStatus.DELIVERED;
		}
		else{
			return null;
		}
	}

	private String selectDeliveryStatus(DeliveryStatus  deliveryStatus){
		if(deliveryStatus.equals(DeliveryStatus.PROCESSING_ORDER)){
			return "PROCESSING_ORDER";
		}
		else if(deliveryStatus.equals(DeliveryStatus.SHIPPING)){
			return "SHIPPING";
		}
		else if(deliveryStatus.equals(DeliveryStatus.DELIVERED)){
			return "DELIVERED";
		}
		else{
			return null;
		}
	}

}
