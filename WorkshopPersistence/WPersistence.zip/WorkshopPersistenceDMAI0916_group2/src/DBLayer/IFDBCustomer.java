package DBLayer;

import java.sql.SQLException;
import java.util.ArrayList;

import modelLayer.*;

public interface IFDBCustomer {

	public ArrayList<Customer> getAllCustomers(boolean retrieveAssociation);
	public Customer getCustomerById(int id, boolean retrieveAssociation);
	public Customer getCustomerByName(String name, boolean retrieveAssociation);
	public int insertCustomer(Customer customer) throws SQLException;
	public int updateCustomer(Customer customer);
	public int deleteCustomer(Customer customer);


}
