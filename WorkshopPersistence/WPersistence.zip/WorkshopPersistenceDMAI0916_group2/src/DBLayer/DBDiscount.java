package DBLayer;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import modelLayer.Discount;
import modelLayer.DiscountType;

public class DBDiscount implements IFDBDiscount{
	
	private Connection con;
	
	public DBDiscount(){
		con = DBConnection.getInstance().getDBcon();
	}

	@Override
	public ArrayList<Discount> getAllDiscounts(boolean retrieveAssociation) {
		return miscWhere("", retrieveAssociation);
	}

	@Override
	public Discount getDiscountByType(String discountType, boolean retrieveAssociation) {
		String wClause = "discountType = '" + discountType +"'";
		return singleWhere(wClause, retrieveAssociation);
	}

	@Override
	public int insertDiscount(Discount discount) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int updateDiscount(Discount discount) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int deleteDiscount(Discount discount) {
		// TODO Auto-generated method stub
		return 0;
	}
	
	private ArrayList<Discount> miscWhere(String wClause, boolean retrieveAssociation)
	{
		ResultSet results;
		ArrayList<Discount> list = new ArrayList<Discount>();	

		String query =  buildQuery(wClause);

		try{ // read the Customer from the database
			Statement stmt = con.createStatement();
			stmt.setQueryTimeout(5);
			results = stmt.executeQuery(query);

			while( results.next() ){
				Discount discObj = new Discount();
				discObj = buildDiscount(results);	
				list.add(discObj);	
			}//end while
			stmt.close();     
			if(retrieveAssociation)
			{
				//do nothing	
			}
		}//end try	
		catch(Exception e){
			System.out.println("Query exception - select: "+e);
			e.printStackTrace();
		}
		return list;
	}
	
	private Discount singleWhere(String wClause, boolean retrieveAssociation){
		ResultSet results;
		Discount discObj = new Discount();

		String query =  buildQuery(wClause);
		System.out.println(query);
		try{ // read the Discount from the database
			Statement stmt = con.createStatement();
			stmt.setQueryTimeout(5);
			results = stmt.executeQuery(query);

			if( results.next() ){
				discObj = buildDiscount(results);
				//association is to be build
				stmt.close();
				if(retrieveAssociation)
				{   
					//do nothing
				}
			}
			else{ //no Discount was found
				discObj = null;
			}
		}//end try	
		catch(Exception e){
			System.out.println("Query exception: "+e);
		}
		return discObj;

	}
	
	private String buildQuery(String wClause)
	{
		String query="SELECT discountType, discountAmount "
				+ "FROM Discount";

		if (wClause.length()>0)
			query=query+" WHERE "+ wClause;

		return query;
	}
	
	private Discount buildDiscount(ResultSet results)
	{   Discount discObj = new Discount();
	try{ // the columns from the table Discount  are used
		discObj.setDiscountType(selectDiscountType(results.getString("discountType")));
		discObj.setDiscountAmount(results.getDouble("discountAmount"));
	}
	catch(Exception e)
	{
		System.out.println("error in building the Discount object");
	}
	return discObj;
	}
	
	private DiscountType selectDiscountType(String discountType){
		if(discountType.equals("DEFAULT")){
			return DiscountType.DEFAULT;
		}
		else if(discountType.equals("CLUB_DISCOUNT")){
			return DiscountType.CLUB_DISCOUNT;
		}
		else{
			return null;
		}
	}
}
