package DBLayer;

import java.util.ArrayList;

import modelLayer.SaleOrder;

public interface IFDBSaleOrder {

	public ArrayList<SaleOrder>	getAllSaleOrders(boolean retrieveAssociation);
	public SaleOrder findSaleOrderById(int id, boolean retrieveAssociation);
	public int insertSaleOrder(SaleOrder SaleOrder) throws Exception;
	public int updateSaleOrder(SaleOrder SaleOrder);
	public int deleteSaleOrder(SaleOrder SaleOrder);
}
