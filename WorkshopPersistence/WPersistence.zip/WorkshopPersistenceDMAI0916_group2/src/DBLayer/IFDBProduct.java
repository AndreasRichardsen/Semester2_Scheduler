package DBLayer;

import java.util.ArrayList;

import modelLayer.Product;

public interface IFDBProduct {
	
	public ArrayList<Product> getAllProducts(boolean retrieveAssociation);
	public Product getProductById(int productId, boolean retrieveAssociation);
	public int insertProduct(Product product);
	public int updateProduct(Product product);
	public int deleteProduct(Product product);

}
