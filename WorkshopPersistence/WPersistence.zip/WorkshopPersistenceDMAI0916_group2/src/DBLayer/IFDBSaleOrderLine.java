package DBLayer;

import java.util.ArrayList;

import modelLayer.SaleOrderLine;

public interface IFDBSaleOrderLine {
	
	public ArrayList<SaleOrderLine> getAllSaleOrderLines(int saleOrderId, boolean retrieveAssociation);
	public SaleOrderLine getSaleOrderLineById(int saleOrderId, int productId, boolean retrieveAssociation);
	public int insertSaleOrderLine(SaleOrderLine SaleOrderLine);
	public int updateSaleOrderLine(SaleOrderLine SaleOrderLine);
	public int deleteSaleOrderLine(SaleOrderLine SaleOrderLine);

}
