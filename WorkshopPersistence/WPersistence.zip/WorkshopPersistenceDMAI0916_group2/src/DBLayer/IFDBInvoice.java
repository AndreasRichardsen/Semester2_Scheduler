package DBLayer;

import java.util.ArrayList;
import modelLayer.*;

public interface IFDBInvoice {
	public ArrayList<Invoice> getAllInvoices(boolean retrieveAssociation);
	public Invoice getInvoiceByNo(int invoiceNo, boolean retrieveAssociation);
	public int insertInvoice(Invoice invoice);
	public int updateInvoice(Invoice invoice);
	public int deleteInvoice(Invoice invoice);

}
