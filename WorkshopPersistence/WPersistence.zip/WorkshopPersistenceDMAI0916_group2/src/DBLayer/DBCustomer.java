package DBLayer;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import modelLayer.Customer;
import modelLayer.CustomerType;
import modelLayer.Discount;

public class DBCustomer implements IFDBCustomer {

	private Connection con;

	public DBCustomer(){
		con = DBConnection.getInstance().getDBcon();
	}

	@Override
	public ArrayList<Customer> getAllCustomers(boolean retrieveAssociation) {
		return miscWhere("", retrieveAssociation);
	}

	@Override
	public Customer getCustomerById(int id, boolean retrieveAssociation) {
		String wClause = " customerId = " + id;
		return singleWhere(wClause, retrieveAssociation);
	}

	@Override
	public Customer getCustomerByName(String name, boolean retrieveAssociation) {
		String wClause = " name like '%" + name + "%'";
		return singleWhere(wClause, retrieveAssociation);
	}

	@Override
	public int insertCustomer(Customer customer) throws SQLException {
		int nextId = GetMax.getMaxId("Select max(customerId) from Customer");
		nextId = nextId + 1;
		System.out.println("next id = " +  nextId);

		int rc = -1;
		String query="INSERT INTO customer(customerId, name, c_address, zipcode, city, phoneNo, email, customerType, discountType)  VALUES("+
				nextId + ", '" +
				customer.getName() + "','"  +
				customer.getAddress() + "','"  +
				customer.getZipcode() + "','" +
				customer.getCity() + "','" +
				customer.getPhoneNo() + "','" +
				customer.getEmail() + "','" +
				"PRIVATE_PERSON" + "','" +
				"DEFAULT')";


		System.out.println("insert : " + query);
		try{ // insert new Customer +  dependent
			Statement stmt = con.createStatement();
			stmt.setQueryTimeout(5);
			rc = stmt.executeUpdate(query);
			stmt.close();
		}//end try
		catch(SQLException ex){
			System.out.println("Customer insertion error");
			throw ex;

		}
		return(rc);
	}

	@Override
	public int updateCustomer(Customer customer) {
		Customer custObj  = customer;
		int rc=-1;

		String query="UPDATE Customer SET "+
				"name ='"+ custObj.getName()+"', "+
				"c_address ='"+ custObj.getAddress() + "', " +
				"zipcode ='"+ custObj.getZipcode() + "', " +
				"city ='"+ custObj.getCity() + "', " +
				"phoneNo ='"+ custObj.getPhoneNo()+"', "+
				"email ='"+ custObj.getEmail()+"', "+
				"customerType ='"+ selectCustomerType(custObj.getCustomerType())+"', "+
				"discountType ='"+ selectDiscountType(custObj.getCustomerType())+"' "+
				" WHERE customerId = '"+ custObj.getId() + "'";
		System.out.println("Update query:" + query);
		try{ // update Customer
			Statement stmt = con.createStatement();
			stmt.setQueryTimeout(5);
			rc = stmt.executeUpdate(query);

			stmt.close();
		}//slut try
		catch(Exception ex){
			System.out.println("Update exception in Customer db: "+ex);
		}
		return(rc);
	}

	@Override
	public int deleteCustomer(Customer customer) {
		int rc=-1;

		String query="DELETE FROM customer WHERE customerId = " +
				customer.getId();
		System.out.println(query);
		try{ // delete from customer
			Statement stmt = con.createStatement();
			stmt.setQueryTimeout(5);
			rc = stmt.executeUpdate(query);
			stmt.close();
		}//finish try	
		catch(Exception ex){
			System.out.println("Delete exception in customer db: "+ex);
		}
		return(rc);
	}


	private ArrayList<Customer> miscWhere(String wClause, boolean retrieveAssociation)
	{
		ResultSet results;
		ArrayList<Customer> list = new ArrayList<Customer>();	

		String query =  buildQuery(wClause);

		try{ // read the Customer from the database
			Statement stmt = con.createStatement();
			stmt.setQueryTimeout(5);
			results = stmt.executeQuery(query);


			while( results.next() ){
				Customer custObj = new Customer();
				custObj = buildCustomer(results);	
				list.add(custObj);	
			}//end while
			stmt.close();     
			if(retrieveAssociation)
			{   //The supervisor and department is to be build as well
				for(Customer custObj : list){
					String discountType = selectDiscountType(custObj.getCustomerType());
					DBDiscount DBdiscount = new DBDiscount();
					Discount discount = DBdiscount.getDiscountByType(discountType, false);
					custObj.setDiscount(discount);
					System.out.println("Discount is selected.");
				}
			}//end if   

		}//finish try	
		catch(Exception e){
			System.out.println("Query exception - select: "+e);
			e.printStackTrace();
		}
		return list;
	}

	private Customer singleWhere(String wClause, boolean retrieveAssociation){
		ResultSet results;
		Customer custObj = new Customer();

		String query =  buildQuery(wClause);
		System.out.println(query);
		try{ // read the customerfrom the database
			Statement stmt = con.createStatement();
			stmt.setQueryTimeout(5);
			results = stmt.executeQuery(query);

			if( results.next() ){
				custObj = buildCustomer(results);
				//assocaition is to be build
				stmt.close();
				if(retrieveAssociation)
				{   
					//try catch later in case of null
					String discountType = selectDiscountType(custObj.getCustomerType());
					DBDiscount DBdiscount = new DBDiscount();
					Discount discount = DBdiscount.getDiscountByType(discountType,false);
					custObj.setDiscount(discount);
					System.out.println("Discount is selected.");
				}
			}
			else{ //no Customer was found
				custObj = null;
			}
		}//end try	
		catch(Exception e){
			System.out.println("Query exception: "+e);
		}
		return custObj;

	}

	private String buildQuery(String wClause)
	{
		String query="SELECT customerId, name, c_address, zipcode, city, phoneNo, email, customerType, discountType  "
				+ "FROM customer";

		if (wClause.length()>0)
			query=query+" WHERE "+ wClause;

		return query;
	}

	private Customer buildCustomer(ResultSet results)
	{   Customer custObj = new Customer();
	try{ // the columns from the table customer  are used
		custObj.setId(results.getInt("customerId"));
		custObj.setName(results.getString("name"));
		custObj.setAddress(results.getString("c_address"));
		custObj.setZipcode(results.getString("zipcode"));
		custObj.setCity(results.getString("city"));
		custObj.setPhoneNo(results.getString("phoneNo"));
		custObj.setEmail(results.getString("email"));
		custObj.setCustomerType(selectCustomerType(results.getString("customerType")));
		custObj.setDiscount(null);
	}
	catch(Exception e)
	{
		System.out.println("error in building the Customer object");
	}
	return custObj;
	}

	public CustomerType selectCustomerType(String customerType){
		if(customerType.equalsIgnoreCase("PRIVATE_PERSON")){
			return CustomerType.PRIVATE_PERSON;
		}
		else if(customerType.equalsIgnoreCase("CLUB")){
			return CustomerType.CLUB;
		}
		else{
			return null;
		}
	}

	private String selectCustomerType(CustomerType customerType){
		if(customerType.equals(CustomerType.PRIVATE_PERSON)){
			return "PRIVATE_PERSON";
		}
		else if(customerType.equals(CustomerType.CLUB)){
			return "CLUB";
		}
		else{
			return null;
		}
	}

	public String selectDiscountType(CustomerType customerType){
		if(customerType.equals(CustomerType.PRIVATE_PERSON)){
			return "DEFAULT";
		}
		else if(customerType.equals(CustomerType.CLUB)){
			return "CLUB_DISCOUNT";
		}
		else{
			return null;
		}
	}



	public static void main(String args[]){

		//		Customer c1 = new Customer(4, "Sanguy", "Godsbanen", "9000", "Aalborg", "12345678", "TheLama@UCN.dk", CustomerType.PRIVATE_PERSON, new Discount(DiscountType.DEFAULT, 10));
		//		Customer c2 = new Customer("Mary", "Godsbanen", "9000", "Aalborg", "12345678", "TheLama@UCN.dk", CustomerType.PRIVATE_PERSON, new Discount(DiscountType.DEFAULT, 10));
		//		Customer c3 = new Customer("Douchebag", "Godsbanen", "9000", "Aalborg", "12345678", "TheLama@UCN.dk", CustomerType.PRIVATE_PERSON, new Discount(DiscountType.DEFAULT, 10));
		DBCustomer test = new DBCustomer();
		//test.insertCustomer(c1);
		//test.insertCustomer(c2);
		//test.insertCustomer(c3);
		//test.deleteCustomer(c1);

		//		ArrayList<Customer> list = test.getAllCustomers(true);
		//		for(Customer c: list){
		//			System.out.println(c.toString());
		//		}



	}
}
