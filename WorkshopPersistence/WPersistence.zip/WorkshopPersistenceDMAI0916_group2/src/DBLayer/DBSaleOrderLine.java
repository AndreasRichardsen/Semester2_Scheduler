package DBLayer;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import modelLayer.SaleOrderLine;
import modelLayer.TypeOfPurchase;
import modelLayer.Product;

public class DBSaleOrderLine implements IFDBSaleOrderLine{
	private Connection con;

	public DBSaleOrderLine(){
		con = DBConnection.getInstance().getDBcon();
	}

	@Override
	public ArrayList<SaleOrderLine> getAllSaleOrderLines(int saleOrderId, boolean retrieveAssociation) {
		return miscWhere("saleOrderId = '" + saleOrderId + "'", retrieveAssociation);
	}

	@Override
	public SaleOrderLine getSaleOrderLineById(int saleOrderId, int productId, boolean retrieveAssociation) {
		String wClause = " saleOrderId = " + saleOrderId + " AND productId = " + productId;
		return singleWhere(wClause, retrieveAssociation);
	}

	@Override
	public int insertSaleOrderLine(SaleOrderLine SaleOrderLine) {

		int rc = -1;
		String query="INSERT INTO SaleOrderLine(productId, saleOrderId, quantity, typeOfPurchase) "
				+ "VALUES("+
				SaleOrderLine.getProduct().getId() + ","  +
				SaleOrderLine.getSaleOrderId() + ","  +
				SaleOrderLine.getQuantity() + ",'" +
				SaleOrderLine.getTypeOfPurchase() + "')";


		System.out.println("insert : " + query);
		try{ // insert new SaleOrderLine +  dependent
			Statement stmt = con.createStatement();
			stmt.setQueryTimeout(5);
			rc = stmt.executeUpdate(query);
			stmt.close();
		}//end try
		catch(SQLException ex){
			System.out.println("SaleOrderLine insertion error");
			ex.printStackTrace();

		}
		return(rc);
	}

	@Override
	public int updateSaleOrderLine(SaleOrderLine SaleOrderLine) {
		SaleOrderLine saleOrderLineObj  = SaleOrderLine;
		int rc=-1;

		String query="UPDATE SaleOrderLine SET "+
				"quantity ="+ saleOrderLineObj.getQuantity()+", "+
				"typeOfPurchase ='"+ selectTypeOfPurchase(saleOrderLineObj.getTypeOfPurchase()) + "', " +
				" where productId = " + saleOrderLineObj.getProduct().getId() + "AND saleOrderId = " + saleOrderLineObj.getSaleOrderId();
		System.out.println("Update query:" + query);
		try{ // update SaleOrderLine
			DBConnection.startTransaction();
			Statement stmt = con.createStatement();
			stmt.setQueryTimeout(5);
			rc = stmt.executeUpdate(query);
			stmt.close();
			DBConnection.commitTransaction();
		}//finish try
		catch(Exception ex){
			System.out.println("Update exception in SaleOrderLine db: "+ex);
			DBConnection.rollbackTransaction();
			ex.printStackTrace();
		}
		return(rc);
	}

	@Override
	public int deleteSaleOrderLine(SaleOrderLine saleOrderLine) {
		int rc=-1;

		String query="DELETE FROM SaleOrderLine "
				+ "WHERE productId = " + saleOrderLine.getProduct().getId() + "AND saleOrderId =" + saleOrderLine.getSaleOrderId();
		System.out.println(query);
		try{ // delete from SaleOrderLine
			Statement stmt = con.createStatement();
			stmt.setQueryTimeout(5);
			rc = stmt.executeUpdate(query);
			stmt.close();
		}//finish try	
		catch(Exception ex){
			System.out.println("Delete exception in SaleOrderLine db: "+ex);
		}
		return(rc);
	}


	private ArrayList<SaleOrderLine> miscWhere(String wClause, boolean retrieveAssociation)
	{
		ResultSet results;
		ArrayList<SaleOrderLine> list = new ArrayList<SaleOrderLine>();	

		String query =  buildQuery(wClause);

		try{ // read the SaleOrderLine from the database
			Statement stmt = con.createStatement();
			stmt.setQueryTimeout(5);
			results = stmt.executeQuery(query);


			while( results.next() ){
				SaleOrderLine saleOrderLineObj = new SaleOrderLine();
				saleOrderLineObj = buildSaleOrderLine(results);	
				list.add(saleOrderLineObj);	
			}//end while
			//stmt.close();
			if(retrieveAssociation)
			{   //The supervisor and department is to be build as well
				for(SaleOrderLine saleOrderLineObj : list){
					int productId = saleOrderLineObj.getProduct().getId();
					DBProduct dbProduct = new DBProduct();
					Product product = dbProduct.getProductById(productId,true);
					saleOrderLineObj.setProduct(product);;
					System.out.println("Product is selected.");
				}
			}//end if   
			

		}//finish try	
		catch(Exception e){
			System.out.println("Query exception - select: "+e);
			e.printStackTrace();
		}
		return list;
	}

	private SaleOrderLine singleWhere(String wClause, boolean retrieveAssociation){
		ResultSet results;
		SaleOrderLine saleOrderLineObj = new SaleOrderLine();

		String query =  buildQuery(wClause);
		System.out.println(query);
		try{ // read the SaleOrderLinefrom the database
			Statement stmt = con.createStatement();
			stmt.setQueryTimeout(5);
			results = stmt.executeQuery(query);

			if( results.next() ){
				saleOrderLineObj = buildSaleOrderLine(results);
				//Association is to be build
				stmt.close();
				if(retrieveAssociation)
				{   
					//try catch later in case of null
					int productId = results.getInt("productId");
					DBProduct dbProduct = new DBProduct();
					Product product = dbProduct.getProductById(productId,true);
					saleOrderLineObj.setProduct(product);;
					System.out.println("Product is selected.");
				}
			}
			else{ //no SaleOrderLine was found
				saleOrderLineObj = null;
			}
		}//end try	
		catch(Exception e){
			System.out.println("Query exception: "+e);
		}
		return saleOrderLineObj;

	}

	private String buildQuery(String wClause)
	{
		String query="SELECT productId, saleOrderId, quantity, typeOfPurchase "
				+ "FROM SaleOrderLine";

		if (wClause.length()>0)
			query=query+" WHERE "+ wClause;

		return query;
	}

	private SaleOrderLine buildSaleOrderLine(ResultSet results)
	{   SaleOrderLine saleOrderLineObj = new SaleOrderLine();
	try{ // the columns from the table SaleOrderLine  are used
		saleOrderLineObj.setSaleOrderId(results.getInt("SaleOrderId"));
		saleOrderLineObj.setQuantity(results.getInt("quantity"));
		saleOrderLineObj.setTypeOfPurchase(selectTypeOfPurchase(results.getString("typeOfPurchase")));
		saleOrderLineObj.setProduct(new Product(results.getInt("productId")));
	}
	catch(Exception e)
	{
		System.out.println("error in building the SaleOrderLine object");
	}
	return saleOrderLineObj;
	}

	private TypeOfPurchase selectTypeOfPurchase(String typeOfPurchase){
		if(typeOfPurchase.equalsIgnoreCase("SALE")){
			return TypeOfPurchase.SALE;
		}
		else if(typeOfPurchase.equalsIgnoreCase("RENT")){
			return TypeOfPurchase.RENT;
		}
		else{
			return null;
		}
	}

	private String selectTypeOfPurchase(TypeOfPurchase typeOfPurchase){
		if(typeOfPurchase.equals(TypeOfPurchase.SALE)){
			return "SALE";
		}
		else if(typeOfPurchase.equals(TypeOfPurchase.RENT)){
			return "RENT";
		}
		else{
			return null;
		}
	}
}

