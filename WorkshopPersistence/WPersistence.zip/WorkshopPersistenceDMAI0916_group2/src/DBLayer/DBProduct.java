package DBLayer;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import modelLayer.Product;
import modelLayer.SalePrice;
import modelLayer.Warehouse;

public class DBProduct implements IFDBProduct {

	private Connection con;

	public DBProduct(){
		con = DBConnection.getInstance().getDBcon();
	}

	@Override
	public ArrayList<Product> getAllProducts(boolean retrieveAssociation) {
		return miscWhere("", retrieveAssociation);
	}

	@Override
	public Product getProductById(int productId, boolean retrieveAssociation) {
		String wClause = " productId = " + productId;
		return singleWhere(wClause, retrieveAssociation);
	}

	@Override
	public int insertProduct(Product product) {
		int nextId = GetMax.getMaxId("Select max(productId) from Product");
		nextId = nextId + 1;
		System.out.println("next id = " +  nextId);

		int rc = -1;
		String query="INSERT INTO Product(productId, name, countryOfOrigin, p_description, productType, stock, warehouseId  "
				+ "VALUES("+
				nextId + ", '" +
				product.getName() + "','"  +
				product.getCountryOfOrigin() + "','"  +
				product.getDescription() + "','" +
				product.getProductType() + "'," +
				product.getStock() + "," +
				product.getWarehouse().getId() + ")";
		


		System.out.println("insert : " + query);
		try{ // insert new Product +  dependent
			Statement stmt = con.createStatement();
			stmt.setQueryTimeout(5);
			rc = stmt.executeUpdate(query);
			stmt.close();
		}//end try
		catch(SQLException ex){
			System.out.println("Product insertion error");

		}
		return(rc);
	}

	@Override
	public int updateProduct(Product product) {
		Product productObj  = product;
		int rc=-1;

		String query="UPDATE Product SET "+
				"name ='"+ productObj.getName() + "', " +
				"countryOfOrigin ='"+ productObj.getCountryOfOrigin() + "', " +
				"p_description ='"+ productObj.getDescription() + "', " +
				"productType ='"+ productObj.getProductType()+"', "+
				"stock ="+ productObj.getStock()+", "+
				"warehouseId ="+ productObj.getWarehouse().getId()+
				" WHERE productId = '"+ productObj.getId() + "'";
		System.out.println("Update query:" + query);
		try{ // update Product
			Statement stmt = con.createStatement();
			stmt.setQueryTimeout(5);
			rc = stmt.executeUpdate(query);

			stmt.close();
		}//finish try
		catch(Exception ex){
			System.out.println("Update exception in Product db: "+ex);
		}
		return(rc);
	}

	@Override
	public int deleteProduct(Product product) {
		int rc=-1;

		String query="DELETE FROM Product WHERE productId = " +
				product.getId();
		System.out.println(query);
		try{ // delete from product
			Statement stmt = con.createStatement();
			stmt.setQueryTimeout(5);
			rc = stmt.executeUpdate(query);
			stmt.close();
		}//finish try	
		catch(Exception ex){
			System.out.println("Delete exception in product db: "+ex);
		}
		return(rc);
	}

	private ArrayList<Product> miscWhere(String wClause, boolean retrieveAssociation)
	{
		ResultSet results;
		ArrayList<Product> list = new ArrayList<Product>();	

		String query =  buildQuery(wClause);

		try{ // read the Product from the database
			Statement stmt = con.createStatement();
			stmt.setQueryTimeout(5);
			results = stmt.executeQuery(query);


			while( results.next() ){
				Product productObj = new Product();
				productObj = buildProduct(results);	
				list.add(productObj);	
			}//end while
			stmt.close();     
			if(retrieveAssociation)
			{   //The supervisor and department is to be build as well
				for(Product productObj : list){
					DBSalePrice dbSalePrice = new DBSalePrice();
					SalePrice salePrice = dbSalePrice.getCurrentSalePriceByProductId(productObj.getId(),false);
					productObj.setSalePrice(salePrice);
					System.out.println("SalePrice is selected.");
					
					DBWarehouse dbWarehouse = new DBWarehouse();
					Warehouse warehouse = dbWarehouse.getWarehouseById(1, false);
					productObj.setWarehouse(warehouse);
					System.out.println("Warehouse is selected.");
				}
			}//end if   

		}//Finish try	
		catch(Exception e){
			System.out.println("Query exception - select: "+e);
			e.printStackTrace();
		}
		return list;
	}

	private Product singleWhere(String wClause, boolean retrieveAssociation){
		ResultSet results;
		Product productObj = new Product();

		String query =  buildQuery(wClause);
		System.out.println(query);
		try{ // read the product from the database
			Statement stmt = con.createStatement();
			stmt.setQueryTimeout(5);
			results = stmt.executeQuery(query);

			if( results.next() ){
				productObj = buildProduct(results);
				//Association is to be build
				stmt.close();
				if(retrieveAssociation)
				{   
					//try catch later in case of null
					DBSalePrice dbSalePrice = new DBSalePrice();
					SalePrice salePrice = dbSalePrice.getCurrentSalePriceByProductId(productObj.getId(),false);
					productObj.setSalePrice(salePrice);
					System.out.println("SalePrice is selected.");
					
					DBWarehouse dbWarehouse = new DBWarehouse();
					Warehouse warehouse = dbWarehouse.getWarehouseById(1,false);
					productObj.setWarehouse(warehouse);
					System.out.println("Warehouse is selected.");
				}
			}
			else{ //no Product was found
				productObj = null;
			}
		}//end try	
		catch(Exception e){
			System.out.println("Query exception: "+e);
		}
		return productObj;

	}

	private String buildQuery(String wClause)
	{
		String query="SELECT productId, name, countryOfOrigin, p_description, productType, stock, warehouseId "
				+ "FROM product";

		if (wClause.length()>0)
			query=query+" WHERE "+ wClause;

		return query;
	}

	private Product buildProduct(ResultSet results)
	{   Product productObj = new Product();
	try{ // the columns from the table product  are used
		productObj.setId(results.getInt("productId"));
		productObj.setName(results.getString("name"));
		productObj.setCountryOfOrigin(results.getString("countryOfOrigin"));
		productObj.setDescription(results.getString("p_description"));
		productObj.setSalePrice(null);
		productObj.setStock(results.getInt("stock"));
		productObj.setWarehouse(null);
		productObj.setProductType(results.getString("productType"));
	}
	catch(Exception e)
	{
		System.out.println("error in building the Product object");
	}
	return productObj;
	}

}
