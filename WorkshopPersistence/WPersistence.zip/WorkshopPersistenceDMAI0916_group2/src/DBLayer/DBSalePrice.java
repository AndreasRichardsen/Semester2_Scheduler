package DBLayer;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;

import modelLayer.SalePrice;

public class DBSalePrice implements IFDBSalePrice{

	private Connection con;

	public DBSalePrice(){
		con = DBConnection.getInstance().getDBcon();
	}

	@Override
	public ArrayList<SalePrice> getAllSalePrices(boolean retrieveAssociation) {
		return miscWhere("", retrieveAssociation);
	}

	@Override
	public SalePrice getCurrentSalePriceByProductId(int productId, boolean retrieveAssociation) {
		String wClause = " productId = " + productId;
		return singleWhere(wClause, retrieveAssociation);
	}

	@Override
	public SalePrice getSalePriceByProductIdAndDate(int productId, Date date, boolean retrieveAssociation) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int insertSalePrice(SalePrice SalePrice) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int updateSalePrice(SalePrice SalePrice) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int deleteSalePrice(SalePrice SalePrice) {
		// TODO Auto-generated method stub
		return 0;
	}

	private ArrayList<SalePrice> miscWhere(String wClause, boolean retrieveAssociation)
	{
		ResultSet results;
		ArrayList<SalePrice> list = new ArrayList<SalePrice>();	

		String query =  buildQuery(wClause);

		try{ // read the SalePrice from the database
			Statement stmt = con.createStatement();
			stmt.setQueryTimeout(5);
			results = stmt.executeQuery(query);


			while( results.next() ){
				SalePrice SalePriceObj = new SalePrice();
				SalePriceObj = buildSalePrice(results);	
				list.add(SalePriceObj);	
			}//end while
			stmt.close();     
			if(retrieveAssociation)
			{   //The supervisor and department is to be build as well
//				for(SalePrice SalePriceObj : list){
//					//do nothing
//				}
			}//end if   

		}//Finish try	
		catch(Exception e){
			System.out.println("Query exception - select: "+e);
			e.printStackTrace();
		}
		return list;
	}

	private SalePrice singleWhere(String wClause, boolean retrieveAssociation){
		ResultSet results;
		SalePrice SalePriceObj = new SalePrice();

		String query =  buildQuery(wClause);
		System.out.println(query);
		try{ // read the SalePrice from the database
			Statement stmt = con.createStatement();
			stmt.setQueryTimeout(5);
			results = stmt.executeQuery(query);

			if( results.next() ){
				SalePriceObj = buildSalePrice(results);
				//Association is to be build
				stmt.close();
				if(retrieveAssociation)
				{   
					//do nothing
				}
			}
			else{ //no SalePrice was found
				SalePriceObj = null;
			}
		}//end try	
		catch(Exception e){
			System.out.println("Query exception: "+e);
		}
		return SalePriceObj;

	}

	private String buildQuery(String wClause)
	{
		String query="SELECT productId, startDate, salePrice, rentPrice "
				+ "FROM SalePrice";

		if (wClause.length()>0)
			query=query+" WHERE "+ wClause;

		return query;
	}

	private SalePrice buildSalePrice(ResultSet results)
	{   SalePrice SalePriceObj = new SalePrice();
	try{ // the columns from the table SalePrice  are used
		SalePriceObj.setProductId(results.getInt("productId"));
		SalePriceObj.setStartDate(results.getDate("startDate"));
		SalePriceObj.setSalePrice(results.getDouble("salePrice"));
		SalePriceObj.setRentPrice(results.getDouble("rentPrice"));
	}
	catch(Exception e)
	{
		System.out.println("error in building the SalePrice object");
	}
	return SalePriceObj;
	}

}
