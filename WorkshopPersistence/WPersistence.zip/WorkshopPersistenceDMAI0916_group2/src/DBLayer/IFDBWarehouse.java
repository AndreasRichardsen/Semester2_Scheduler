package DBLayer;

import java.util.ArrayList;

import modelLayer.Warehouse;

public interface IFDBWarehouse {

	public ArrayList<Warehouse> getAllWarehouses(boolean retrieveAssociation);
	public Warehouse getWarehouseById(int productId, boolean retrieveAssociation);
	public int insertWarehouse(Warehouse product);
	public int updateWarehouse(Warehouse product);
	public int deleteWarehouse(Warehouse product);

}
