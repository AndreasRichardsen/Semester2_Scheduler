package DBLayer;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import modelLayer.Warehouse;

public class DBWarehouse implements IFDBWarehouse{
	
	private Connection con;
	
	public DBWarehouse(){
		con = DBConnection.getInstance().getDBcon();
	}

	@Override
	public ArrayList<Warehouse> getAllWarehouses(boolean retrieveAssociation) {
		return miscWhere("", retrieveAssociation);
	}

	@Override
	public Warehouse getWarehouseById(int warehouseId, boolean retrieveAssociation) {
		String wClause = "warehouseId = " + warehouseId;
		return singleWhere(wClause, retrieveAssociation);
	}

	@Override
	public int insertWarehouse(Warehouse product) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int updateWarehouse(Warehouse product) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int deleteWarehouse(Warehouse product) {
		// TODO Auto-generated method stub
		return 0;
	}
	
	private ArrayList<Warehouse> miscWhere(String wClause, boolean retrieveAssociation)
	{
		ResultSet results;
		ArrayList<Warehouse> list = new ArrayList<Warehouse>();	

		String query =  buildQuery(wClause);

		try{ // read the Warehouse from the database
			Statement stmt = con.createStatement();
			stmt.setQueryTimeout(5);
			results = stmt.executeQuery(query);


			while( results.next() ){
				Warehouse warehouseObj = new Warehouse();
				warehouseObj = buildWarehouse(results);	
				list.add(warehouseObj);	
			}//end while
			stmt.close();     
			if(retrieveAssociation)
			{   //The supervisor and department is to be build as well
//				for(Warehouse warehouseObj : list){
//					//do nothing
//				}
			}//end if   

		}//Finish try	
		catch(Exception e){
			System.out.println("Query exception - select: "+e);
			e.printStackTrace();
		}
		return list;
	}
	
	private Warehouse singleWhere(String wClause, boolean retrieveAssociation){
		ResultSet results;
		Warehouse warehouseObj = new Warehouse();

		String query =  buildQuery(wClause);
		System.out.println(query);
		try{ // read the product from the database
			Statement stmt = con.createStatement();
			stmt.setQueryTimeout(5);
			results = stmt.executeQuery(query);

			if( results.next() ){
				warehouseObj = buildWarehouse(results);
				//Association is to be build
				stmt.close();
				if(retrieveAssociation)
				{   
					//do nothing
				}
			}
			else{ //no Warehouse was found
				warehouseObj = null;
			}
		}//end try	
		catch(Exception e){
			System.out.println("Query exception: "+e);
		}
		return warehouseObj;

	}
	
	private String buildQuery(String wClause)
	{
		String query="SELECT warehouseId, name, capacity, warehouseType "
				+ "FROM Warehouse";

		if (wClause.length()>0)
			query=query+" WHERE "+ wClause;

		return query;
	}

	private Warehouse buildWarehouse(ResultSet results)
	{   Warehouse warehouseObj = new Warehouse();
	try{ // the columns from the table product  are used
		warehouseObj.setId(results.getInt("warehouseId"));
		warehouseObj.setName(results.getString("name"));
		warehouseObj.setCapacity(results.getDouble("capacity"));
		warehouseObj.setWarehouseType(results.getString("warehouseType"));
	}
	catch(Exception e)
	{
		System.out.println("error in building the Warehouse object");
	}
	return warehouseObj;
	}

}
