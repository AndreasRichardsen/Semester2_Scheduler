package DBLayer;

import java.util.ArrayList;

import modelLayer.Discount;

public interface IFDBDiscount {
	
	public ArrayList<Discount> getAllDiscounts(boolean retrieveAssociation);
	public Discount getDiscountByType(String discountType, boolean retrieveAssociation);
	public int insertDiscount(Discount discount);
	public int updateDiscount(Discount discount);
	public int deleteDiscount(Discount discount);


}
