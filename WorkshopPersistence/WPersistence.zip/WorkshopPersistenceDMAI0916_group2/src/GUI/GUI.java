package GUI;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import DBLayer.DBCustomer;
import DBLayer.DBDiscount;
import controlLayer.SaleOrderController;
import controlLayer.StockException;
import modelLayer.Customer;
import modelLayer.CustomerType;
import modelLayer.Discount;
import modelLayer.SaleOrder;
import modelLayer.SaleOrderLine;
import modelLayer.TypeOfPurchase;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.sql.SQLException;
import java.util.ArrayList;

public class GUI {


	private SaleOrderController sOController;
	private int selectedCustomerId = -1;

	JTextField name;
	JTextField address;
	JTextField zipcode;
	JTextField city;
	JTextField phoneNo;
	JTextField email;
	JTextField type;
	DefaultTableModel table_model;
	DefaultTableModel table_model2;
	double discountAmount = 0;

	public GUI(){
		sOController = new SaleOrderController();
		sOController.createSaleOrder();
		
		

		JFrame frame = new JFrame("Western Company");

		frame.setSize(700, 650);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLocationRelativeTo(null);
		frame.setResizable(false);
		JPanel panel = new JPanel(new GridBagLayout());
		frame.getContentPane().add(panel, BorderLayout.WEST);
		GridBagConstraints c = new GridBagConstraints();
		c.weighty=1;

		c.insets= new Insets(0,20,0,0);
		JLabel title = new JLabel("Customer");
		c.gridx=0;
		c.gridy=0;
		panel.add(title, c);

		name = new JTextField("name", 10);
		genericFocusListener(name);
		c.gridx=1;
		c.gridy=1;
		panel.add(name, c);

		address = new JTextField("address", 10);
		genericFocusListener(address);
		c.gridx=1;
		c.gridy=2;
		panel.add(address, c);

		zipcode = new JTextField("zipcode", 10);
		genericFocusListener(zipcode);
		c.gridx=1;
		c.gridy=3;
		panel.add(zipcode, c);

		city= new JTextField("city", 10);
		genericFocusListener(city);
		c.gridx=1;
		c.gridy=4;
		panel.add(city, c);

		phoneNo = new JTextField("phone no.", 10);
		genericFocusListener(phoneNo);
		c.gridx=2;
		c.gridy=1;
		panel.add(phoneNo, c);

		email = new JTextField("email", 10);
		genericFocusListener(email);
		c.gridx=2;
		c.gridy=2;
		panel.add(email, c);

		type = new JTextField("customer type", 10);
		genericFocusListener(type);
		c.gridx=2;
		c.gridy=3;
		panel.add(type, c);

		c.insets= new Insets(0,150,0,0);
		JButton find_customer = new JButton("Find Customer");
		find_customer.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e) {
				String id = JOptionPane.showInputDialog(frame, "Enter customer Id");
				int customerId = Integer.parseInt(id);
				DBCustomer dbCustomer = new DBCustomer();
				Customer customer = dbCustomer.getCustomerById(customerId, true);
				if(customer != null){
					name.setText(customer.getName());
					address.setText(customer.getAddress());
					zipcode.setText(customer.getZipcode());
					city.setText(customer.getCity());
					phoneNo.setText(customer.getPhoneNo());
					email.setText(customer.getEmail());
					type.setText(Customer.selectCustomerType(customer.getCustomerType()));
					selectedCustomerId = customer.getId();
					discountAmount = customer.getDiscount().getDiscountAmount();
					refreshTotalTable();

				}
				else{
					clearCustomer();

				}

			}
		});
		c.gridx=3;
		c.gridy=1;
		panel.add(find_customer, c);

		JButton save_customer = new JButton("Save Customer");
		save_customer.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e) {
				String c_name = name.getText();
				String c_address = address.getText();
				String c_zipcode = zipcode.getText();
				String c_city = city.getText();
				String c_phoneNo = phoneNo.getText();
				String c_email = email.getText();
				String c_cType = type.getText();
				CustomerType cType = SaleOrder.selectCustomerType(c_cType);
				DBDiscount dbDiscount = new DBDiscount();
				DBCustomer dbCustomer = new DBCustomer();
				Discount discount = null;
				try{
					discount = dbDiscount.getDiscountByType((SaleOrder.selectDiscountType(cType)), false);
					Customer customer = new Customer(c_name, c_address, c_zipcode, c_city, c_phoneNo, c_email, cType, discount);
					try{ 
						dbCustomer.insertCustomer(customer);
						selectedCustomerId = dbCustomer.getCustomerByName(name.getText(), false).getId();
						discountAmount = discount.getDiscountAmount();
						refreshTotalTable();
						JOptionPane.showMessageDialog(frame, "Customer Successfully added");
					}
					catch(SQLException ex){
						JOptionPane.showMessageDialog(frame, "Error inserting customer", "Error Dialog",
								JOptionPane.ERROR_MESSAGE);
					}
				}
				catch(Exception ex){
					JOptionPane.showMessageDialog(frame, "Error inserting customer", "Error Dialog",
							JOptionPane.ERROR_MESSAGE);
				}



			}
		});
		c.gridx=3;
		c.gridy=2;
		panel.add(save_customer, c);

		JButton clear = new JButton("Clear");
		clear.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e) {
				clearCustomer();
				discountAmount = 0;
				refreshTotalTable();

			}
		});
		c.gridx=3;
		c.gridy=4;
		panel.add(clear, c);

		JSeparator sep = new JSeparator();
		sep.setPreferredSize(new Dimension(20,30));
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridwidth = 20;
		c.gridx=0;
		c.gridy=5;
		panel.add(sep, c);
		c.gridwidth=1;

		c.insets= new Insets(0,20,0,0);
		JLabel title2 = new JLabel("Order");
		c.gridx=0;
		c.gridy=5;
		panel.add(title2, c);











		String saleOrderColumnNames[]= {"Product Id","Name","Quantity","Purchase Type","Price Per Unit","Line Total"};
		ArrayList<SaleOrderLine> saleOrderLines  = sOController.getSaleOrder().getSaleOrderLines();

		table_model = new DefaultTableModel();
		table_model.setColumnIdentifiers(saleOrderColumnNames);
		for(SaleOrderLine sol: saleOrderLines){
			Object[] row = newRow(sol);
			table_model.addRow(row);
		}
		JTable table = new JTable(table_model);
		c.gridwidth = 5;
		c.gridheight=2;
		c.gridx=1;
		c.gridy=6;
		JScrollPane sp = new JScrollPane(table);
		sp.setPreferredSize(new Dimension(100, 100));
		panel.add(sp, c);  
		c.gridheight=1;


		JButton addProduct = new JButton("Add Product");
		addProduct.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e) {
				String id = "";
				String stringQuantity = "";
				JTextField field1 = new JTextField();
				JTextField field2 = new JTextField();
				Object[] message = {
						"Input productId:", field1,
						"Input quantity:", field2,
				};
				int option = JOptionPane.showConfirmDialog(null, message, "Enter all your values", JOptionPane.OK_CANCEL_OPTION);
				if (option == JOptionPane.OK_OPTION)
				{
					id = field1.getText();
					stringQuantity = field2.getText();
				}
				else{
					System.out.println("Add product error");
				}

				int productId = Integer.parseInt(id);
				int quantity = Integer.parseInt(stringQuantity);
				int i = sOController.getSaleOrder().getSaleOrderLines().size();
				try {
					sOController.addProductToSaleOrder(productId, quantity);
					table_model.addRow(newRow(sOController.getSaleOrder().getSaleOrderLines().get(i)));
					refreshTotalTable();
				} catch (StockException e1) {
					JOptionPane.showMessageDialog(frame, e1, "Error Dialog",
							JOptionPane.ERROR_MESSAGE);
				}


			}
		});
		c.gridwidth = 1;
		c.gridx=1;
		c.gridy=8;
		panel.add(addProduct, c);

		JButton removeProduct = new JButton("Remove Product");
		removeProduct.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e) {
				int i = table.getSelectedRow();
				if(i >= 0){
					sOController.getSaleOrder().getSaleOrderLines().remove(i);
					table_model.removeRow(i);
					refreshTotalTable();

				}
				else{
					System.out.println("Remove product error");
				}

			}
		});
		c.gridx=2;
		c.gridy=8;
		panel.add(removeProduct, c);

		JButton clearOrder = new JButton("Clear Order");
		clearOrder.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e) {
				table_model.setRowCount(0);
				sOController.getSaleOrder().getSaleOrderLines().clear();
				sOController.getSaleOrder().createSaleOrderLineList();
				refreshTotalTable();

			}
		});
		c.gridx=2;
		c.gridy=9;
		panel.add(clearOrder, c);

		String totalCollumnNames[]= {"Subtotal","Discount","Total"};
		table_model2 = new DefaultTableModel();
		table_model2.setColumnIdentifiers(totalCollumnNames);
		table_model2.addRow(totalTable());
		JTable tableTotal = new JTable(table_model2);
		JScrollPane sp2 = new JScrollPane(tableTotal);
		c.gridheight=2;
		c.gridx=3;
		c.gridy=8;
		sp2.setPreferredSize(new Dimension(30, 39));
		panel.add(sp2, c);
		c.gridheight=2;


		JSeparator sep2 = new JSeparator();
		sep2.setPreferredSize(new Dimension(20,30));
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridwidth = 20;
		c.gridx=0;
		c.gridy=10;
		panel.add(sep2, c);
		c.gridwidth=1;

		JButton saveOrder = new JButton("Save Order");
		saveOrder.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e) {
				CustomerType cType = Customer.selectCustomerType(type.getText());
				DBDiscount dbDiscount = new DBDiscount();
				Discount discount = dbDiscount.getDiscountByType(type.getText(), false);
				Customer customer = new Customer();
				DBCustomer dbCustomer = new DBCustomer();
				if(selectedCustomerId > 0){
					customer = dbCustomer.getCustomerById(selectedCustomerId, true);
				}
				else{
					customer = new Customer(name.getText(), address.getText(), zipcode.getText(), city.getText(), phoneNo.getText(), email.getText(), cType, discount);
				}
				sOController.getSaleOrder().setCustomer(customer);
				try{
					int rc = sOController.recordSaleOrder();
					JOptionPane.showMessageDialog(frame, "Order Successfully saved");
					reset();
				}
				catch(Exception ex){
					JOptionPane.showMessageDialog(frame, "Error saving Order", "Error Dialog",
							JOptionPane.ERROR_MESSAGE);
				}


			}
		});
		c.gridheight=1;
		c.gridx=3;
		c.gridy=12;
		panel.add(saveOrder, c);

		JButton cancelOrder = new JButton("Cancel Order");
		cancelOrder.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e) {
				reset();
				System.exit(0);
			}


		});
		c.gridx=2;
		c.gridy=12;
		panel.add(cancelOrder, c);

		frame.setVisible(true);


	}

	private void genericFocusListener(JTextField textfield){
		String defaultText = textfield.getText();
		textfield.addFocusListener(new FocusListener() {
			@Override
			public void focusGained(FocusEvent e){
				if(textfield.getText().equalsIgnoreCase(defaultText)){
					textfield.setText("");
				}
			}
			@Override
			public void focusLost(FocusEvent e){
				if(textfield.getText().length() <= 0){
					textfield.setText(defaultText);
				}
			}

		});

	}

	public Object[] newRow(SaleOrderLine sol){
		Object[] row = new Object[6];
		row[0] = sol.getProduct().getId();
		row[1] = sol.getProduct().getName();
		row[2] = sol.getQuantity();
		row[3] = sol.getTypeOfPurchase();
		if(row[3] == TypeOfPurchase.SALE){
			row[4] = sol.getProduct().getSalePrice().getSalePrice();
		}
		else{
			row[4] =  sol.getProduct().getSalePrice().getRentPrice();
		}
		row[5] = Double.parseDouble(row[2].toString()) * Double.parseDouble(row [4].toString());
		return row;
	}

	public Object[] totalTable(){
		double runningTotal = 0;
		if(sOController.getSaleOrder().getSaleOrderLines().size() > 0){
			for(SaleOrderLine saleOrderLine: sOController.getSaleOrder().getSaleOrderLines()){
				runningTotal += saleOrderLine.getQuantity()*saleOrderLine.getProduct().getSalePrice().getSalePrice();
			}
		}
		double subtotal = runningTotal;


		try{
			discountAmount = sOController.getSaleOrder().getCustomer().getDiscount().getDiscountAmount();
		}
		catch(Exception e){
			System.out.println("Discount is null");        
		}
		Object[] totalRow = new Object[3];
		totalRow[0] = Double.toString(subtotal);
		totalRow[1] = Double.toString(discountAmount);
		totalRow[2] = Double.toString(subtotal*(100-discountAmount)/100);
		return totalRow;
	}

	public void refreshTotalTable(){
		table_model2.setRowCount(0);
		table_model2.addRow(totalTable());
	}

	public void clearCustomer(){
		name.setText("name");
		address.setText("address");
		zipcode.setText("zipcode");
		city.setText("city");
		phoneNo.setText("phone no.");
		email.setText("email");
		type.setText("customer type");
		selectedCustomerId = -1;
	}

	public void reset(){
		sOController.setSaleOrder(null);
		sOController.createSaleOrder();
		clearCustomer();
		table_model.setRowCount(0);
		discountAmount = 0;
		refreshTotalTable();
	}






	public static void main(String[] args) {
		new GUI();


	}
}