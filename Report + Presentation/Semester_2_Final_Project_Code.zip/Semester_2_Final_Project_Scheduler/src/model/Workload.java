package model;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * The workload class is designed to hold information regarding
 * a date's number of reservations and information about events
 * and then calculate an estimated number of required shifts.
 * 
 * @author Sangey Lama
 * @version 1.0 
 */
public class Workload {

	private LocalDate date;
	private int noOfGuestsReservations;
	private int noOfGuestsEvent;
	private List<Shift> shifts;
	private boolean modified;

	public Workload() {
		super();
		this.shifts = new ArrayList<>();
		this.modified = false;
	}

	public Workload(LocalDate date, int noOfGuestsReservations, int noOfGuestsEvent) {
		super();
		this.date = date;
		this.noOfGuestsReservations = noOfGuestsReservations;
		this.noOfGuestsEvent = noOfGuestsEvent;
		this.shifts = new ArrayList<>();
		this.modified = false;
	}

	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}

	public int getNoOfGuestsReservations() {
		return noOfGuestsReservations;
	}

	public void setNoOfGuestsReservations(int noOfGuestsReservations) {
		this.noOfGuestsReservations = noOfGuestsReservations;
	}

	public int getNoOfGuestsEvent() {
		return noOfGuestsEvent;
	}

	public void setNoOfGuestsEvent(int noOfGuestsEvent) {
		this.noOfGuestsEvent = noOfGuestsEvent;
	}

	public List<Shift> getShifts(){
		return shifts;
	}

	public void addShift(Shift shift){
		shifts.add(shift);
	}

	public void removeShift(Shift shift){
		shifts.remove(shift);
	}

	public Shift getShift(int index){
		if(shifts.size() > 0 && index != -1 && index < shifts.size())
			return shifts.get(index);
		else
			return null;
	}

	public boolean getModified(){
		return modified;
	}

	public void setModified(boolean isModified){
		this.modified = isModified;
	}

	@Override
	public String toString() {
		return "\nWorkload [date=" + date + ", noOfGuestsReservations=" + noOfGuestsReservations
				+ ", noOfGuestsEvent=" + noOfGuestsEvent + ", \n\tshifts=" + shifts + "]";
	}
}
